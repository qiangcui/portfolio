# cuidi

移动优先

- @madia query的代码无需执行。
- 无需加载大分辨率的图片，加载复杂的css样式。